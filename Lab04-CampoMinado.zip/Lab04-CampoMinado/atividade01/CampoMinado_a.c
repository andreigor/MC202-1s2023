#include <stdio.h>
#include <stdlib.h>

typedef struct _ponto{
    int x, y;
}Ponto;

typedef struct _bomba{
    Ponto coordenadas;
    int raio;
}Bomba;

/*Le as dimensoes do tabuleiro*/
Ponto LeDimensoes(){
    Ponto coordenadas;
    scanf("%dx%d", &coordenadas.x, &coordenadas.y);
    return coordenadas;
}

/*Cria um vetor contendo n bombas*/
Bomba *CriaBomba(int n){
    Bomba *bombas = (Bomba *)calloc(n, sizeof(Bomba));
    return (bombas);
}

/*Le as n bombas digitadas pelo usuario*/
Bomba *LeBombas(int n, Ponto p){
    Bomba *b = CriaBomba(n); 
    for (int i = 0; i < n; i++){
        scanf("%d %d %d", &b[i].coordenadas.x, &b[i].coordenadas.y, &b[i].raio);
    }
    return (b);
}


/*Cria um tabuleiro na memoria de tamanho nlin x ncol*/
int **CriaTabuleiro (int nlin, int ncol){
    int **tab = (int **)calloc(nlin, sizeof(int *)); //Cria um ponteiro de ponteiro para as linhas
    for (int i = 0; i < nlin; i++){
        tab[i] = (int *)calloc(ncol, sizeof(int)); // Cria um ponteiro de cada linha para sua coluna
    }
    return tab;
}

/*Destroi um tabuleiro no heap de tamanho n x n*/
void DestroiTabuleiro (int ***tab, int n){
    if ((*tab) != NULL){
        for (int i = 0; i < n; i++){
            free((*tab)[i]);
        }
        free (*tab);
        *tab = NULL;
    }
}

/*Printa tabuleiro*/
void ImprimeTabuleiro(int **tab, int nlin, int ncol){
    for (int i = 0; i < nlin; i++){
        for (int j = 0; j < ncol; j++){
            printf ("%d ",tab[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}

//Inicializa um tabuleiro com zeros
void InicializaTabuleiro(int **tab, int nlin, int ncol){
    for (int i = 0; i < nlin; i++){
        for (int j = 0; j < ncol; j++){
            tab[i][j] = 0;
        }
    }
}

void PreencheTabuleiro(int **tab, int nlin, int ncol, Bomba *bombas, int nbombas){
//Percorre cada bomba do vetor
    for (int i = 0; i < nbombas; i++){
        int x = bombas[i].coordenadas.x;
        int y = bombas[i].coordenadas.y;
        int r = bombas[i].raio;
        int j, k;
        for (j = x - r; j <= x + r; j++){
            for (k = y - r; k <= y + r; k++){
                if ((j < nlin && j >= 0) && (k < ncol && k >= 0)){
                    tab[j][k] = 1;
                }
            } 
        }
    }
}


int main(){
    int n; //Numero de bombas
    Ponto cc;
    Ponto tamanho = LeDimensoes();
    scanf("%d", &n);
    if (n < 0){
        printf("-1");
        return 0;
    }
    Bomba *b = LeBombas(n, tamanho);
    scanf("%d %d", &cc.x, &cc.y);

    if (cc.x < 0 || cc.x >= tamanho.x || cc.y < 0 || cc.y >= tamanho.y){
        printf("-1");
        return 0;
    }

//Checa se as dimensoes do tabuleiro sao validas
if (tamanho.x <= 0 || tamanho.y <= 0){
        printf("-1");
        return 0;
    }

//Checa se as coordenadas sao possiveis
    for (int i = 0; i < n; i++) {
        int x = b[i].coordenadas.x;
        int y = b[i].coordenadas.y;
        int r = b[i].raio;
        if ((x >= tamanho.x || x < 0)|| (y >= tamanho.y || y < 0) || (r < 0)){
            printf("-1");
            return 0;
        }
    }

    //Cria um tabuleiro de nlin e ncol
    int **tabuleiro = CriaTabuleiro(tamanho.x, tamanho.y);
    InicializaTabuleiro(tabuleiro, tamanho.x, tamanho.y);
    // ImprimeTabuleiro(tabuleiro, tamanho.x, tamanho.y);
    PreencheTabuleiro(tabuleiro, tamanho.x, tamanho.y, b, n);
    // ImprimeTabuleiro(tabuleiro, tamanho.x, tamanho.y);

    if (tabuleiro[cc.x][cc.y] == 1){
        printf("Perigoso");
    }
    else{
        printf("Seguro");
    }
    DestroiTabuleiro(&tabuleiro, tamanho.x);
    free(b);
    return 0;
}